/* ─────────────────────────────────────────────────────────────────────────
   Guided Meditation Portal — live, interactive in-browser app emulation.
   This isn't a screenshot: every screen below is a real, driven UI — tap
   tracks, switch tabs, watch the reactive night-sky canvas pulse, just like
   the actual Android app's NightSkyView.react() system. Built to mirror the
   real bottom-nav tabs (Sounds · Alarm · Spirit · Settings · Unlock).
   ───────────────────────────────────────────────────────────────────────── */
(function () {
  "use strict";

  var TRACKS = [
    { title: "Letting Go of Tension",   sub: "Guided · Body & breath",   len: "12:04", secs: 724 },
    { title: "Body Scan for Sleep",     sub: "Guided · Wind-down",       len: "15:30", secs: 930 },
    { title: "Open Awareness",          sub: "Guided · Stillness",       len: "10:12", secs: 612 },
    { title: "Loving-Kindness Flow",    sub: "Guided · Heart practice",  len: "11:48", secs: 708 },
    { title: "Morning Breath Reset",    sub: "Guided · Energize",        len: "8:55",  secs: 535 }
  ];

  var SPIRIT_LINES = [
    "Notice how your shoulders feel right now. Want to start with a two-minute body scan?",
    "It's been a long day — a loving-kindness practice might feel good tonight. Shall we?",
    "If your mind is racing, try four slow breaths with me: in for four, hold for four, out for six.",
    "You've meditated 4 days in a row 🤍 — want to keep the streak going with something short?",
    "Restless before bed? 'Body Scan for Sleep' usually helps people drift off gently."
  ];

  var state = {
    tab: "sounds",
    trackIndex: 0,
    playing: true,
    progress: 0.18,     // 0..1
    spiritIndex: 0,
    alarmEnabled: true,
    alarmTime: "6:30 AM",
    settingsToggles: { sound: true, haptics: true, reduceMotion: false }
  };

  var root, canvas, ctx, dpr;
  var ripples = [];
  var stars = [];
  var lastT = performance.now();

  /* ── UI sound effects ──────────────────────────────────────────────────
     Short tones live in /sounds (sounds/*.wav) — generated once with the
     same gentle, bell-like palette as the in-app SynthTone generator, then
     simply played back here via <audio>. If a file fails to load for any
     reason, we fall back to synthesizing the tone live with the Web Audio
     API so the demo never goes silent. ─────────────────────────────────── */
  var SOUND_FILES = {
    tap:    "sounds/tap.wav",
    select: "sounds/select.wav",
    play:   "sounds/play.wav",
    pause:  "sounds/pause.wav",
    chat:   "sounds/chat.wav",
    toggle: "sounds/toggle.wav",
    chime:  "sounds/chime.wav"
  };
  var soundEls = {};
  var soundFailed = {};

  function getSoundEl(name) {
    if (soundEls[name]) return soundEls[name];
    var src = SOUND_FILES[name];
    if (!src) return null;
    var a = new Audio(src);
    a.preload = "auto";
    a.volume = 0.55;
    a.addEventListener("error", function () { soundFailed[name] = true; });
    soundEls[name] = a;
    return a;
  }

  function playSampledSfx(name) {
    if (soundFailed[name]) return false;
    var a = getSoundEl(name);
    if (!a) return false;
    try {
      var inst = a.cloneNode(true); // allow overlapping plays
      inst.volume = a.volume;
      var p = inst.play();
      if (p && typeof p.catch === "function") p.catch(function () {});
      return true;
    } catch (e) { return false; }
  }

  // Real audio previews — short clips lifted directly from the app's own
  // narrated meditation tracks (res/raw/*.mp3), so the "Now Playing" demo
  // plays genuine app audio rather than a placeholder.
  var TRACK_PREVIEWS = [
    "sounds/preview-breathing-out-tension.mp3",
    "sounds/preview-breathing-out-tension-ii.mp3",
    "sounds/preview-quiet-river-flow.mp3"
  ];
  var previewAudio = null;
  var previewStopTimer = null;
  var PREVIEW_DURATION_MS = 30000; // 30 seconds

  function getPreviewAudio() {
    if (!previewAudio) {
      previewAudio = new Audio();
      previewAudio.loop = true;  // loop the short clip to fill 30s
      previewAudio.volume = 0.5;
    }
    return previewAudio;
  }
  function previewSrcFor(trackIndex) {
    return TRACK_PREVIEWS[trackIndex % TRACK_PREVIEWS.length];
  }
  function playTrackPreview(trackIndex) {
    if (!soundOn) return;
    var a = getPreviewAudio();
    var src = previewSrcFor(trackIndex);
    if (!a.src || a.src.indexOf(src) === -1) {
      a.src = src;
      a.currentTime = 0;
    }
    var p = a.play();
    if (p && typeof p.catch === "function") p.catch(function () {});
    // Auto-stop after 30 seconds
    if (previewStopTimer) clearTimeout(previewStopTimer);
    previewStopTimer = setTimeout(function () {
      stopTrackPreview();
      // Update UI to show stopped state
      state.playing = false;
      render();
    }, PREVIEW_DURATION_MS);
  }
  function pauseTrackPreview() {
    if (previewStopTimer) { clearTimeout(previewStopTimer); previewStopTimer = null; }
    if (previewAudio) previewAudio.pause();
  }
  function stopTrackPreview() {
    if (previewStopTimer) { clearTimeout(previewStopTimer); previewStopTimer = null; }
    if (previewAudio) { previewAudio.pause(); previewAudio.currentTime = 0; }
  }

  var actx = null;
  var soundOn = true;

  function audioCtx() {
    if (actx) return actx;
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    try { actx = new AC(); } catch (e) { actx = null; }
    return actx;
  }

  function chime(freq, opts) {
    if (!soundOn) return;
    var ac = audioCtx();
    if (!ac) return;
    if (ac.state === "suspended") { ac.resume(); }
    opts = opts || {};
    var dur   = opts.dur   != null ? opts.dur   : 0.22;
    var gain  = opts.gain  != null ? opts.gain  : 0.07;
    var type  = opts.type  || "sine";
    var glide = opts.glide || 0;
    var t0 = ac.currentTime;

    var osc = ac.createOscillator();
    var amp = ac.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t0);
    if (glide) osc.frequency.exponentialRampToValueAtTime(Math.max(20, freq + glide), t0 + dur * 0.85);

    // soft attack / release envelope — gentle, never harsh
    amp.gain.setValueAtTime(0.0001, t0);
    amp.gain.exponentialRampToValueAtTime(gain, t0 + 0.018);
    amp.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);

    osc.connect(amp);
    amp.connect(ac.destination);
    osc.start(t0);
    osc.stop(t0 + dur + 0.05);
  }

  // A tiny palette of calm, bell-like sounds for different interactions —
  // soft sine/triangle tones in a pentatonic-ish range so nothing clashes.
  var SFX = {
    tap:     function () { chime(660, { dur: 0.12, gain: 0.05, type: "sine" }); },
    select:  function () { chime(740, { dur: 0.16, gain: 0.055, type: "sine", glide: 140 }); },
    play:    function () { chime(523, { dur: 0.26, gain: 0.06, type: "triangle", glide: 220 }); },
    pause:   function () { chime(392, { dur: 0.22, gain: 0.05, type: "triangle", glide: -80 }); },
    chat:    function () { chime(880, { dur: 0.18, gain: 0.045, type: "sine", glide: 60 }); },
    toggle:  function () { chime(587, { dur: 0.1,  gain: 0.05, type: "square", glide: 0 }); },
    chime:   function () {
      // a gentle two-note chime for special moments (unlock / timer)
      chime(660, { dur: 0.3, gain: 0.06, type: "sine" });
      setTimeout(function () { chime(880, { dur: 0.45, gain: 0.05, type: "sine", glide: 40 }); }, 110);
    }
  };

  var REACTION_SFX = {
    PLAY: SFX.play, PAUSE: SFX.pause, SELECT: SFX.select,
    CHAT: SFX.chat, UNLOCK: SFX.chime, TIMER: SFX.toggle
  };
  var REACTION_SAMPLE = {
    PLAY: "play", PAUSE: "pause", SELECT: "select",
    CHAT: "chat", UNLOCK: "chime", TIMER: "toggle"
  };

  function playSfx(kind) {
    if (!soundOn) return;
    // Prefer the real sample file from /sounds; fall back to a live
    // synthesized tone only if playback of the file fails for some reason.
    var sampleName = REACTION_SAMPLE[kind] || "tap";
    var played = playSampledSfx(sampleName);
    if (!played) {
      var fn = REACTION_SFX[kind] || SFX.tap;
      try { fn(); } catch (e) {}
    }
  }

  function $(sel, scope) { return (scope || root).querySelector(sel); }
  function $all(sel, scope) { return Array.prototype.slice.call((scope || root).querySelectorAll(sel)); }

  /* ── Reactive canvas backdrop (mirrors NightSkyView.react / ReactionKind) ── */
  var REACTIONS = {
    PLAY:   { tint: [76, 141, 250],  punch: 0.9 },
    PAUSE:  { tint: [110, 123, 174], punch: 0.45 },
    SELECT: { tint: [125, 211, 252], punch: 0.7 },
    CHAT:   { tint: [168, 199, 255], punch: 0.65 },
    UNLOCK: { tint: [255, 210, 125], punch: 1.0 },
    TIMER:  { tint: [103, 232, 201], punch: 0.55 }
  };
  var energy = 0.4, tint = REACTIONS.PLAY.tint;

  function react(kind, ox, oy) {
    var r = REACTIONS[kind] || REACTIONS.SELECT;
    energy = Math.min(1.6, energy + r.punch);
    tint = r.tint;
    ripples.push({ x: ox != null ? ox : 0.5, y: oy != null ? oy : 0.4, t: 0, color: r.tint });
    if (ripples.length > 6) ripples.shift();
    playSfx(kind);
  }

  function setupCanvas() {
    canvas = $(".demo-sky");
    ctx = canvas.getContext("2d");
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    resizeCanvas();
    window.addEventListener("resize", resizeCanvas);
    for (var i = 0; i < 46; i++) {
      stars.push({
        x: Math.random(), y: Math.random(),
        r: Math.random() * 1.6 + 0.4,
        tw: Math.random() * Math.PI * 2,
        speed: Math.random() * 0.6 + 0.2
      });
    }
    requestAnimationFrame(loop);
  }

  function resizeCanvas() {
    var rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
  }

  function loop(now) {
    var dt = Math.min(0.05, (now - lastT) / 1000);
    lastT = now;
    energy *= 0.965;
    draw(now / 1000, dt);
    requestAnimationFrame(loop);
  }

  function draw(t, dt) {
    var w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    // base cosmic gradient, shifts subtly with energy + tint
    var g = ctx.createLinearGradient(0, 0, 0, h);
    var e = Math.min(1, energy);
    g.addColorStop(0, "rgba(" + tint[0] + "," + tint[1] + "," + tint[2] + "," + (0.16 + e * 0.18) + ")");
    g.addColorStop(0.55, "rgba(16,17,46,1)");
    g.addColorStop(1, "rgba(14,27,58,1)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);

    // drifting stars, twinkle faster when "energy" is higher (user just acted)
    for (var i = 0; i < stars.length; i++) {
      var s = stars[i];
      s.tw += dt * (0.6 + s.speed * (0.6 + e));
      var alpha = 0.35 + Math.abs(Math.sin(s.tw)) * 0.55;
      ctx.beginPath();
      ctx.arc(s.x * w, s.y * h, s.r * dpr * (1 + e * 0.4), 0, Math.PI * 2);
      ctx.fillStyle = "rgba(255,255,255," + alpha.toFixed(2) + ")";
      ctx.fill();
      s.x += dt * 0.004 * (s.speed);
      if (s.x > 1.05) s.x = -0.05;
    }

    // ripples — expand outward from the point of interaction, just like the app
    for (var j = ripples.length - 1; j >= 0; j--) {
      var rp = ripples[j];
      rp.t += dt;
      var life = 2.4;
      if (rp.t > life) { ripples.splice(j, 1); continue; }
      var p = rp.t / life;
      var radius = p * Math.max(w, h) * 0.62;
      var alpha = (1 - p) * 0.35;
      ctx.beginPath();
      ctx.arc(rp.x * w, rp.y * h, radius, 0, Math.PI * 2);
      ctx.strokeStyle = "rgba(" + rp.color[0] + "," + rp.color[1] + "," + rp.color[2] + "," + alpha.toFixed(2) + ")";
      ctx.lineWidth = 2 * dpr;
      ctx.stroke();
    }

    // central glowing orb — pulses with "energy"
    var cx = w * 0.5, cy = h * 0.36;
    var orbR = (34 + e * 22) * dpr;
    var og = ctx.createRadialGradient(cx, cy, 0, cx, cy, orbR * 2.4);
    og.addColorStop(0, "rgba(" + tint[0] + "," + tint[1] + "," + tint[2] + "," + (0.55 + e * 0.3) + ")");
    og.addColorStop(1, "rgba(" + tint[0] + "," + tint[1] + "," + tint[2] + ",0)");
    ctx.fillStyle = og;
    ctx.beginPath();
    ctx.arc(cx, cy, orbR * 2.4, 0, Math.PI * 2);
    ctx.fill();
  }

  /* ── Screen renderers ─────────────────────────────────────────────────── */
  function renderSounds() {
    var tr = TRACKS[state.trackIndex];
    var pct = Math.round(state.progress * 100);
    var html =
      '<div class="now-playing">' +
        '<div class="label">Now playing · Track ' + (state.trackIndex + 1) + ' of 23</div>' +
        '<div class="title">' + tr.title + '</div>' +
        '<div class="sub">' + tr.sub + ' · ' + tr.len + ' · Repeat: All</div>' +
        '<div class="bar"><i style="width:' + pct + '%"></i></div>' +
        '<div class="controls">' +
          '<span class="ctl" data-act="prev">⏮</span>' +
          '<div class="play" data-act="toggle">' + (state.playing ? "⏸" : "▶") + '</div>' +
          '<span class="ctl" data-act="next">⏭</span>' +
        '</div>' +
      '</div>' +
      '<div class="track-list">' +
      TRACKS.map(function (t, i) {
        return '<div class="track-row' + (i === state.trackIndex ? " active" : "") + '" data-track="' + i + '">' +
          '<span class="dot"></span><span class="t">' + t.title + '</span><span class="len">' + t.len + '</span>' +
        '</div>';
      }).join("") +
      '</div>';
    return html;
  }

  function renderAlarm() {
    return '<div class="demo-pane">' +
      '<div class="label" style="text-align:center;margin-top:4px;">Meditation Alarm</div>' +
      '<div class="alarm-clock">' + state.alarmTime + '</div>' +
      '<div class="sub" style="text-align:center;">Wakes you with “Morning Breath Reset” or a gentle synth tone</div>' +
      '<div class="toggle-row">' +
        '<span>Alarm enabled</span>' +
        '<div class="switch ' + (state.alarmEnabled ? "on" : "") + '" data-act="alarm-toggle"><i></i></div>' +
      '</div>' +
      '<div class="toggle-row" style="opacity:.55;">' +
        '<span>Wake sound</span><span style="color:var(--accent-2);font-size:11px;">Narrated track ▾</span>' +
      '</div>' +
      '<div class="toggle-row" style="opacity:.55;">' +
        '<span>Fade-in volume</span><span style="color:var(--accent-2);font-size:11px;">90 sec ▾</span>' +
      '</div>' +
    '</div>';
  }

  function renderSpirit() {
    var line = SPIRIT_LINES[state.spiritIndex];
    return '<div class="demo-pane spirit-pane">' +
      '<div class="spirit-bubble-row">' +
        '<div class="mini-avatar">🤍</div>' +
        '<div class="bubble">' + line + '</div>' +
      '</div>' +
      '<div class="spirit-suggestions">' +
        '<button class="chip" data-act="spirit-next">Suggest a practice</button>' +
        '<button class="chip" data-act="spirit-next">I feel anxious</button>' +
        '<button class="chip" data-act="spirit-next">Help me sleep</button>' +
      '</div>' +
      '<div class="sub" style="text-align:center;margin-top:14px;">Tap a chip — Spirit responds instantly, fully on-device</div>' +
    '</div>';
  }

  function renderSettings() {
    var t = state.settingsToggles;
    function row(key, label) {
      return '<div class="toggle-row"><span>' + label + '</span>' +
        '<div class="switch ' + (t[key] ? "on" : "") + '" data-act="setting" data-key="' + key + '"><i></i></div></div>';
    }
    return '<div class="demo-pane">' +
      '<div class="label" style="margin-top:4px;">Settings</div>' +
      row("sound", "Sound effects") +
      row("haptics", "Haptic feedback") +
      row("reduceMotion", "Reduce background motion") +
      '<div class="toggle-row" style="opacity:.55;"><span>Theme</span><span style="color:var(--accent-2);font-size:11px;">Cosmic blue ▾</span></div>' +
      '<div class="toggle-row" style="opacity:.55;"><span>Sleep timer</span><span style="color:var(--accent-2);font-size:11px;">Up to 8 hrs ▾</span></div>' +
    '</div>';
  }

  function renderUnlock() {
    return '<div class="demo-pane unlock-pane">' +
      '<div class="unlock-emoji">✨</div>' +
      '<div class="title" style="text-align:center;">Unlock the Full Portal</div>' +
      '<div class="sub" style="text-align:center;">Every guided meditation · Spirit · Meditation alarm · No ads</div>' +
      '<div class="unlock-price">$2.00 <span>one time, forever</span></div>' +
      '<button class="mini-btn" data-act="unlock-tap">Unlock — $2.00</button>' +
      '<div class="sub" style="text-align:center;margin-top:10px;opacity:.7;">No subscriptions. Ever.</div>' +
    '</div>';
  }

  var SCREENS = { sounds: renderSounds, alarm: renderAlarm, spirit: renderSpirit, settings: renderSettings, unlock: renderUnlock };
  var TAB_REACTION = { sounds: "SELECT", alarm: "TIMER", spirit: "CHAT", settings: "SELECT", unlock: "UNLOCK" };

  function renderScreen() {
    var body = $(".app-body");
    body.innerHTML = SCREENS[state.tab]();
    bindScreenEvents();
  }

  function setTab(tab, originX, originY) {
    if (state.tab === tab) return;
    var leavingSounds = state.tab === "sounds";
    state.tab = tab;
    $all(".app-navbar .item").forEach(function (el) {
      el.classList.toggle("active", el.getAttribute("data-tab") === tab);
    });
    react(TAB_REACTION[tab] || "SELECT", originX, originY);
    if (leavingSounds) pauseTrackPreview();
    else if (tab === "sounds" && state.playing) playTrackPreview(state.trackIndex);
    renderScreen();
  }

  function bindScreenEvents() {
    $all("[data-track]").forEach(function (el) {
      el.addEventListener("click", function () {
        state.trackIndex = parseInt(el.getAttribute("data-track"), 10);
        state.progress = 0.04;
        state.playing = true;
        react("SELECT", 0.5, 0.42);
        playTrackPreview(state.trackIndex);
        renderScreen();
      });
    });
    var toggle = $('[data-act="toggle"]');
    if (toggle) toggle.addEventListener("click", function () {
      state.playing = !state.playing;
      react(state.playing ? "PLAY" : "PAUSE", 0.5, 0.5);
      if (state.playing) playTrackPreview(state.trackIndex);
      else pauseTrackPreview();
      renderScreen();
    });
    var prev = $('[data-act="prev"]');
    if (prev) prev.addEventListener("click", function () {
      state.trackIndex = (state.trackIndex - 1 + TRACKS.length) % TRACKS.length;
      state.progress = 0.04; react("SELECT", 0.3, 0.5);
      if (state.playing) playTrackPreview(state.trackIndex);
      renderScreen();
    });
    var next = $('[data-act="next"]');
    if (next) next.addEventListener("click", function () {
      state.trackIndex = (state.trackIndex + 1) % TRACKS.length;
      state.progress = 0.04; react("SELECT", 0.7, 0.5);
      if (state.playing) playTrackPreview(state.trackIndex);
      renderScreen();
    });
    var alarmToggle = $('[data-act="alarm-toggle"]');
    if (alarmToggle) alarmToggle.addEventListener("click", function () {
      state.alarmEnabled = !state.alarmEnabled;
      react("TIMER", 0.5, 0.4);
      renderScreen();
    });
    $all('[data-act="setting"]').forEach(function (el) {
      el.addEventListener("click", function () {
        var key = el.getAttribute("data-key");
        state.settingsToggles[key] = !state.settingsToggles[key];
        react("SELECT", 0.5, 0.4);
        renderScreen();
      });
    });
    $all('[data-act="spirit-next"]').forEach(function (el) {
      el.addEventListener("click", function () {
        state.spiritIndex = (state.spiritIndex + 1) % SPIRIT_LINES.length;
        react("CHAT", 0.3, 0.3);
        renderScreen();
      });
    });
    var unlockTap = $('[data-act="unlock-tap"]');
    if (unlockTap) unlockTap.addEventListener("click", function () {
      react("UNLOCK", 0.5, 0.5);
      unlockTap.textContent = "✨ Thanks for trying the demo!";
      setTimeout(function () {
        if ($('[data-act="unlock-tap"]')) $('[data-act="unlock-tap"]').textContent = "Unlock — $2.00";
      }, 1800);
    });
  }

  /* ── Progress ticker — advances the "now playing" bar while in Sounds tab ── */
  function tickProgress() {
    if (state.tab === "sounds" && state.playing) {
      state.progress += 0.0028;
      if (state.progress >= 1) {
        state.progress = 0;
        state.trackIndex = (state.trackIndex + 1) % TRACKS.length;
        react("SELECT", 0.5, 0.4);
      }
      var bar = $(".now-playing .bar i");
      if (bar) bar.style.width = Math.round(state.progress * 100) + "%";
      else renderScreen();
    }
    setTimeout(tickProgress, 220);
  }

  /* ── Boot ─────────────────────────────────────────────────────────────── */
  function init() {
    root = document.querySelector(".phone-frame");
    if (!root) return;
    setupCanvas();
    var soundBtn = $('[data-act="sound-toggle"]');
    if (soundBtn) soundBtn.addEventListener("click", function () {
      soundOn = !soundOn;
      soundBtn.textContent = soundOn ? "🔊" : "🔇";
      soundBtn.classList.toggle("muted", !soundOn);
      audioCtx(); // create/resume on this gesture (used as fallback only)
      if (soundOn) {
        if (!playSampledSfx("tap")) SFX.tap();
        if (state.tab === "sounds" && state.playing) playTrackPreview(state.trackIndex);
      } else {
        pauseTrackPreview();
      }
    });
    $all(".app-navbar .item").forEach(function (el) {
      el.addEventListener("click", function () {
        setTab(el.getAttribute("data-tab"), 0.5, 0.85);
      });
    });
    renderScreen();
    react("PLAY", 0.5, 0.42);
    // Browsers block audio until a user gesture — start the real preview
    // clip on the very first tap/click anywhere in the demo.
    var startPreviewOnce = function () {
      if (state.tab === "sounds" && state.playing) playTrackPreview(state.trackIndex);
      root.removeEventListener("click", startPreviewOnce);
    };
    root.addEventListener("click", startPreviewOnce);

    // Prevent the page from scrolling when the user scrolls inside the phone frame
    root.addEventListener("wheel", function (e) {
      var trackList = root.querySelector(".track-list");
      var appBody   = root.querySelector(".app-body");
      var target    = trackList || appBody;
      if (!target) return;
      var atTop    = target.scrollTop === 0;
      var atBottom = target.scrollTop + target.clientHeight >= target.scrollHeight - 1;
      if (!(atTop && e.deltaY < 0) && !(atBottom && e.deltaY > 0)) {
        e.preventDefault();
        target.scrollTop += e.deltaY;
      }
    }, { passive: false });

    // Touch scroll inside phone frame
    var touchStartY = 0;
    root.addEventListener("touchstart", function (e) {
      touchStartY = e.touches[0].clientY;
    }, { passive: true });
    root.addEventListener("touchmove", function (e) {
      var trackList = root.querySelector(".track-list");
      var appBody   = root.querySelector(".app-body");
      var target    = trackList || appBody;
      if (!target) return;
      var dy       = touchStartY - e.touches[0].clientY;
      var atTop    = target.scrollTop === 0;
      var atBottom = target.scrollTop + target.clientHeight >= target.scrollHeight - 1;
      if (!(atTop && dy < 0) && !(atBottom && dy > 0)) {
        e.preventDefault();
        target.scrollTop += dy;
        touchStartY = e.touches[0].clientY;
      }
    }, { passive: false });

    setTimeout(tickProgress, 600);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
